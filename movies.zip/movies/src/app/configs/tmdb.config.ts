export class TMDB{
  public static search_api="https://api.themoviedb.org/3/search/movie?api_key=d3f52c1a9668c85909b9f50188e541b7&language=en-US&include_adult=false&query=";
  public static baseUrl="http://image.tmdb.org/t/p/w185/";
}
