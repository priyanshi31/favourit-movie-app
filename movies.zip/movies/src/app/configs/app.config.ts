export class App{
  public static apiUrl="http://localhost:3000/";
}
